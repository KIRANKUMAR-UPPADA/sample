package com.bhaiti.kela.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bhaiti.kela.beans.person;
import com.bhaiti.kela.beans.personRegistration;

@Controller
public class personRetrieveController {
	
	@RequestMapping(method = RequestMethod.GET, value="/person")

	@ResponseBody
	public List<person> getperson() {
		return personRegistration.getInstance().getpersonRecords();
	}

}
