package com.bhaiti.kela.beans;

public class personRegistrationReply {
	
	String firstname;
String middlename;

String lastname;

		String phonenumber;
	String registrationStatus;
	
	public String getFirstName() {
		return fisrtname;
	}
	public void setFirstName(String firstname) {
		this.firstname =firstname;
	}
public String getMiddleName() {
		return middlename;
	}
	public void setMiddleName(String middlename) {
		this.middlename =middlename;
	}

public String getLastName() {
		return lastname;
	}
	public void setLastName(String lastname) {
		this.lastname =lastname;
	}

	
	public String getPhoneNumber() {
		return phonenumber;
	}
	public void setPhoneNumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getRegistrationStatus() {
		return registrationStatus;
	}
	public void setRegistrationStatus(String registrationStatus) {
		this.registrationStatus = registrationStatus;
	}	

}
