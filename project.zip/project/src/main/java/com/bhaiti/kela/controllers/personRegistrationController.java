package com.bhaiti.kela.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bhaiti.kela.beans.*;

@Controller
public class personRegistrationController {
	
	@RequestMapping(method = RequestMethod.POST, value="/register/person")

	
	@ResponseBody
	personRegistrationReply registerperson(@RequestBody person person) {
		
		System.out.println("In registerperson");
        personRegistrationReply stdregreply = new personRegistrationReply();           

        personRegistration.getInstance().add(person);

        //We are setting the below value just to reply a message back to the caller
        stdregreply.setFirstName(person.getFirstName());

        stdregreply.setMiddleName(person.getMiddleName());

        stdregreply.setLastName(person.getLastName());                stdregreply.setPhoneNumber(person.getPhoneNumber());
        stdregreply.setRegistrationStatus("Successful");


        return stdregreply;
        
	}

}
