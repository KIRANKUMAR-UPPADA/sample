package com.bhaiti.kela.beans;

import java.util.ArrayList;
import java.util.List;

public class personRegistration {
	
	private List<person> personRecords;
	
	private static personRegistration stdregd = null;
	
	private personRegistration(){
		personRecords = new ArrayList<person>();
	}
	
	public static personRegistration getInstance() {
		
		if(stdregd == null) {
			stdregd = new personRegistration();
			return stdregd;
		}
		else {
			return stdregd;
		}
	}
	
	public void add(person std) {
		personRecords.add(std);
	}
	
	public String upDateperson(person std) {
		
		for(int i=0; i<personRecords.size(); i++)
        {
            person stdn = personRecords.get(i);
            System.out.println(stdn.getPhoneNumber());
            System.out.println(std.getPhoneNumber());
            if(stdn.getPhoneNumber().equals(std.getPhoneNumber())) {
            	personRecords.set(i, std);//update the new record
            	return "Update successful";
            }
        }
		
		return "Update un-successful";
		
	}
	
	public String deleteperson(String phonenumber) {
		
		for(int i=0; i<personRecords.size(); i++)
        {
            person stdn = personRecords.get(i);
            if(stdn.getPhoneNumber().equals(phonenumber)) {
            	personRecords.remove(i);//update the new record
            	return "Delete successful";
            }
        }
		
		return "Delete un-successful";
		
	}

	public List<person> getpersonRecords() {
		return personRecords;
	}

}
