package com.bhaiti.kela.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bhaiti.kela.beans.person;
import com.bhaiti.kela.beans.personRegistration;

@Controller
public class personUpdateController {
	
@RequestMapping(method = RequestMethod.PUT, value="/update/person")

	
	@ResponseBody
	public String updatepersonRecord(@RequestBody person stdn) {		
		System.out.println("In updatepersonRecord");	   
	    return personRegistration.getInstance().upDateperson(stdn);		
	}	

}
